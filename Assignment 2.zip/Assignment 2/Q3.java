import java.util.Scanner;

public class Q3
{
    public static void func(int ...arr)
    {
        System.out.println("The total number of arguments is "+arr.length);
        int max=arr[0],s=0;
        for(int ele: arr)
        {
            s+=ele;
            if (max<ele)
            max=ele;
        }
        System.out.println("The maximum element is"+max);
        System.out.println("The sum of elements is"+s);
    }
    public static void main(String[] args) {
        func(1,2,3,4,5,6,7,8,9);
    }
}
