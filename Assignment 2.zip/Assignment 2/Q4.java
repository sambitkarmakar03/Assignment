import java.util.Scanner;

public class Q4 {
    public static void lowercase(String s)
    {
        s=s.trim();
        for(int i=0;i<s.length();i++)
        {
            if(s.charAt(i)>='A'&&s.charAt(i)<='Z')
            {
                int k=(int)s.charAt(i);
                System.out.print((char)(k+32));
            }
            else
                System.out.print(s.charAt(i));
        }
    }
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        String str;
        str=sc.nextLine();
        lowercase(str);
        System.out.println("\nThe total string length is "+ str.length());
    }
}
