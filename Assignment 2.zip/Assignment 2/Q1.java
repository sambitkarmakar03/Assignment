import java.util.*;
public class Q1 {
    public static double perimeter(int s)
    {
        return 4*s;
    }
    public static double perimeter(long l,long b)
    {
        return 2*(l+b);
    }
    public static double perimeter(double r)
    {
        return 2*(22/7)*r;
    }
    public static double area(int s)
    {
        return s*s;
    }
    public static double area(long l,long b)
    {
        return l*b;
    }
    public static double area(double r)
    {
        return 22/7*r*r;
    }
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("What is side of square");
        int s= sc.nextInt();;
        System.out.println("Perimeter of square "+perimeter(s));
        System.out.println("Area of square "+area(s));
        System.out.println("What is dimensions of rectangle");
        System.out.println("Length");
        long l= sc.nextLong();
        System.out.println("Breadth");
        long b=sc.nextLong();
        System.out.println("Perimeter of rectangle "+perimeter(l,b));
        System.out.println("Area of rectangle "+area(l,b));
        System.out.println("What is the radius of circle ");
        double r= sc.nextDouble();
        System.out.println("Perimeter of circle "+perimeter(r));
        System.out.println("Area of circle "+area(r));
    }
}
