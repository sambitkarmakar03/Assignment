import java.util.Scanner;
public class Q5 {
    public static void array(int ...arr)
    {
        int sum=0;
        for(int ele:arr)
        {
            sum+=ele;
        }
        System.out.println("The sum of elements is "+sum);
        System.out.println("The elements in reverse form is");
        for(int j=(arr.length-1);j>=0;j--)
            System.out.print(" "+arr[j]);
    }
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        array(1,2,3,4,5,6,7,8,9,10);
    }
}
