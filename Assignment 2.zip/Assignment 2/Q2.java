import java.util.Scanner;
public class Q2 {
    public static void bank(String name)
    {
        int k=0;
        name=name.trim();
        name=name.toUpperCase();
        for(int i=0;i<name.length();i++)
        {
            if(name.charAt(i)>='A'&&name.charAt(i)<='Z'||name.charAt(i)==' ')
            k++;
        }
        if(k== name.length())
            System.out.println("Name has no problem");
        else
            System.out.println("Name has problem");
    }
    public static void bank(int age)
    {
        if(age>3&&age<15)
            System.out.println("Age has no problem ");
        else
            System.out.println("Age has problem");
    }
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        String name;
        int b;
        System.out.println("What is your name");
        name=sc.nextLine();
        System.out.println("What is your age");
        b=sc.nextInt();
        bank(name);
        bank(b);
    }
}
